from django.shortcuts import render
from django.contrib import messages
from .models import Product
from .forms import ProductForm, ProductUpdateForm
from django.views.generic import (DetailView,
                                  ListView,
                                  TemplateView)

from django.contrib.auth.decorators import login_required


@login_required
class ProductCreate(TemplateView):
    model = Product
    form_class = ProductForm
    template_name = 'listing/product_form.html'

    def get_success_url(self):
        messages.success(self.request, 'Product added to the marketplace!')
        return self.object.get_absolute_url()


class ProductDetail(DetailView):
    model = Product
    template_name = 'listing/product_detail.html'


class ProductList(ListView):
    model = Product
    template_name = 'listing/product_list.html'

@login_required
class ProductUpdate(TemplateView):
    model = Product
    form_class = ProductUpdateForm
    template_name = 'listing/product_update.html'

    def get_success_url(self):
        messages.success(self.request, 'You have updated your product!')
        return self.object.get_absolute_url()
