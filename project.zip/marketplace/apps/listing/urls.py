from django.contrib import admin
from django.urls import path, include
from marketplace.apps.listing.views import *

app_name = 'listing'
urlpatterns = [
    path('new', ProductCreate.as_view(), name='create'),
    path('edit', ProductUpdate.as_view(), name='update'),
    path('details', ProductDetail.as_view(), name='detail'),
    path('products', ProductList.as_view(), name='list'),

]