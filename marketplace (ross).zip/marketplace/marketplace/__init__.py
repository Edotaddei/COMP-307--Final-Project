import asyncio

asyncio.set_event_loop_policy(asyncio.DefaultEventLoopPolicy())